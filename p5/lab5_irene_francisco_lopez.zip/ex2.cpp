#include <iostream>

/*
2.Write a program that defines a class called MyClass with three data members of type char, int, and bool.
 Make an instance of that class inside the main function.
*/

class MyClass;

class MyClass{
    private:
        char a;
        int b;
        bool c;
};

int main()
{
    MyClass o;
    return 0;
}
