#include <iostream>

/*
1. Write a program that defines an empty class called MyClass and makes an instance of
MyClass in the main function.
*/

class MyClass;

class MyClass{};

int main()
{
    MyClass o;
    return 0;
}
